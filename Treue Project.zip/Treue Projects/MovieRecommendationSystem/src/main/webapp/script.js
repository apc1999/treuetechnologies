document.addEventListener('DOMContentLoaded', function () {
    const recommendButton = document.getElementById('recommendButton');
    const recommendationsDiv = document.getElementById('recommendations');
    
    recommendButton.addEventListener('click', function () {
        const selectedGenre = document.getElementById('genre').value;
        // You would have your recommendation logic here.
        // For now, let's just generate some sample recommendations.
        const recommendedMovies = [
            'Movie 1',
            'Movie 2',
            'Movie 3'
        ];

        recommendationsDiv.innerHTML = '';
        recommendedMovies.forEach(movie => {
            const movieDiv = document.createElement('div');
            movieDiv.classList.add('movie');
            movieDiv.textContent = movie;
            recommendationsDiv.appendChild(movieDiv);
        });
    });
});
/**
 * 
 */